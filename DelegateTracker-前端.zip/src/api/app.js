import {request} from '@/plugins/axios'
import ApiPath from '@/api/api_path'

export function list(query) {
    return request({
        url: '/news',
        method: 'GET',
        params: query
    })
}