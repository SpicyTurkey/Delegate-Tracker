<template>
  <div>
    <el-dialog
        title="welcome"
        :show-close="false"
        :visible.sync="dialogVisible"
        :close-on-click-modal="false"
        :close-on-press-escape="false"
        width="60%">
      <el-form ref="form" :model="form" label-width="80px">
        <el-form-item label="username">
          <el-input v-model="form.username"></el-input>
        </el-form-item>
        <el-form-item label="password">
          <el-input type="password" v-model="form.password"></el-input>
        </el-form-item>
        <el-form-item label="user">
          <el-radio-group v-model="form.resource">
            <el-radio label="admin"></el-radio>
            <el-radio label="user"></el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="onSubmit">login</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>

  </div>
</template>

<script>
export default {
  name: 'LoginView',
  data(){
    return{
      dialogVisible : true,
      form: {
        username: 'admin',
        password: 'admin',
        resource: 'admin'
      }
    }
  },
  methods: {
    onSubmit() {
      this.$router.push("/index")

    }
  }
}
</script>
