<template>
  <div class="contract-detector">
    <h1>智能合约检测工具</h1>

    <div class="content-wrapper">
      <!-- 左侧输入区 -->
      <div class="left-section">
        <div class="code-input">
          <textarea
              v-model="contractCode"
              placeholder="请输入智能合约源码，或上传文件..."
          ></textarea>
        </div>
        <div class="action-buttons">
          <input type="file" @change="handleFileUpload"/>
          <button @click="clearInput">清空所有输入</button>
        </div>
      </div>

      <!-- 右侧功能区 -->
      <div class="right-section">
        <!-- 攻击路径检测 -->
        <div class="function-card">
          <h3>攻击路径检测</h3>
          <div class="input-group">
            <input v-model="solcVersion" placeholder="Solidity 版本"/>
          </div>
          <button @click="detectAttackPath" class="primary-btn">检测攻击路径</button>
          <div class="result-box">
            <pre style="text-align: left">{{ attackPathResult }}</pre>
          </div>
        </div>

        <!-- 攻击路径验证 -->
        <div class="function-card">
          <h3>攻击路径验证</h3>
          <div class="input-group vertical">
            <input v-model="contractName" placeholder="被攻击合约名称"/>
            <input v-model="writingFunction" placeholder="Writing 函数"/>
            <input v-model="readingFunction" placeholder="Reading 函数"/>
          </div>
          <button @click="verifyAttackPath" class="primary-btn">验证攻击路径</button>
          <div class="result-box">
            <pre style="text-align: left">{{ verificationResult }}</pre>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>

import axios from "axios";

export default {

  data() {
    return {
      contractCode: "",
      solcVersion: "",
      contractName: "",
      writingFunction: "",
      readingFunction: "",
      attackPathResult: "",
      verificationResult: ""
    };
  },

  methods: {
    async detectAttackPath() {
      this.attackPathResult = "检测中...";

      if (!this.contractCode || !this.solcVersion) {
        setTimeout(() => {
          this.attackPathResult = "**检测失败：请填写所有字段**";
        }, 500);
        return;
      }
      try {
        this.attackPathResult = "检测中...";
        const response = await axios.post("http://localhost:8888/djjh5/DTaudit1", {
          code: this.contractCode,
          version: this.solcVersion,
        }, {
          headers: {
            'Content-Type': 'application/json'
          }
        });
        setTimeout(() => {
          this.attackPathResult = JSON.stringify(response.data, null, 2);
        }, 500);
      } catch (error) {
        setTimeout(() => {
          this.attackPathResult = "**检测失败：" + error.message + "**";
        }, 500);
      }
    },


    async verifyAttackPath() {
      this.verificationResult = "";

      if (!this.contractCode || !this.solcVersion || !this.contractName || !this.writingFunction || !this.readingFunction) {
        setTimeout(() => {
          this.verificationResult = "**验证失败：请填写所有字段**";
        }, 500);
        return;
      }

      try {
        this.verificationResult = "验证中...";
        const response = await axios.post("http://localhost:8888/djjh5/DTaudit2", {
          code: this.contractCode,
          version: this.solcVersion,
          name: this.contractName,
          writing: this.writingFunction,
          reading: this.readingFunction
        }, {
          headers: {
            'Content-Type': 'application/json'
          }
        });

        setTimeout(() => {
          this.verificationResult = JSON.stringify(response.data, null, 2);
        }, 500);

      } catch (error) {
        setTimeout(() => {
          this.verificationResult = "**验证失败：" + error.message + "**";
        }, 500);
      }

    },

    clearInput() {
      this.contractCode = "";
      this.solcVersion = "";
      this.contractName = "";
      this.targetContract = "";
      this.writingFunction = "";
      this.readingFunction = "";
      this.attackPathResult = "";
      this.verificationResult = "";
      this.contractCode = "";
      this.detectionResult = "";
    },


    handleFileUpload(event) {
      const file = event.target.files[0];
      console.log(file);
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          this.contractCode = e.target.result; // 将文件内容赋值给文本框
        };
        reader.readAsText(file);
        this.contractName = file.name;
      }
    }
  }
};
</script>


<style scoped>
.contract-detector {
  padding: 2rem;
  max-width: 1200px;
  margin: 0 auto;
}

.content-wrapper {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 2rem;
  margin-top: 2rem;
}

.code-input textarea {
  width: 90%;
  height: 600px;
  padding: 1rem;
  border: 2px solid #e0e0e0;
  border-radius: 8px;
  font-family: 'Fira Code', monospace;
}

.function-card {
  background: #fff;
  border-radius: 12px;
  padding: 1.5rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  margin-bottom: 2rem;
}

.input-group {
  display: flex;
  gap: 1rem;
  margin: 1rem 0;
}

.input-group.vertical {
  flex-direction: column;
}

.primary-btn {
  background: #4a90e2;
  color: white;
  padding: 0.8rem 1.5rem;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  transition: background 0.3s;
}

.primary-btn:hover {
  background: #357abd;
}

.result-box {
  margin-top: 1rem;
  padding: 1rem;
  background: #f8f9fa;
  border-radius: 8px;
  max-height: 300px;
  overflow-y: auto;
}

.result-box pre {
  white-space: pre-wrap;
  word-break: break-word;
}
</style>