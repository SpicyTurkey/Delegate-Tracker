<template>
  <el-container style="height: 100vh; border: 1px solid #eee">
    <el-aside width="200px" style="background-color: rgb(238, 241, 246)">
      <el-menu router default-active="/index">
        <el-menu-item style="font-size: 16px" index="/index">合约漏洞检测与利用工具</el-menu-item>
        <el-menu-item index="/djjh5">DelegateTracker</el-menu-item>

      </el-menu>
    </el-aside>

    <el-container>
      <el-header style="text-align: right; font-size: 12px">
        <el-dropdown>
          <i class="el-icon-setting" style="margin-right: 15px"></i>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item>查看</el-dropdown-item>
            <el-dropdown-item>新增</el-dropdown-item>
            <el-dropdown-item>删除</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
        <span>源码审计工具</span>
      </el-header>

      <el-main>
        <router-view/>

      </el-main>
    </el-container>
  </el-container>
</template>

<style>
.el-header {
  background-color: #B3C0D1;
  color: #333;
  line-height: 60px;
}

.el-aside {
  color: #333;
}
</style>

<script>
export default {
  name: 'IndexView',
  data() {
    const item = {
      date: '2024-07-16',
      name: 'cwr',
      address: '郑州科学大道'
    };
    return {
      tableData: Array(20).fill(item)
    }
  }
};
</script>