<template>
  <div>
    <h1 style="text-align: center;font-size: 24px">你好，欢迎</h1>
    <el-carousel :interval="4000" type="card">
      <el-carousel-item v-for="(item, index) in items" :key="index">
        <img :src="item" alt="轮播图" style="max-width: 60%;max-height: 60%">
      </el-carousel-item>
    </el-carousel>
  </div>
</template>

<script>
export default {
  data() {
    return {
      items: [
        require('@/assets/BTC.jpg'),
        require('@/assets/EOS.jpg'),
        require('@/assets/ETC.jpg')
      ]
    };
  }
};
</script>