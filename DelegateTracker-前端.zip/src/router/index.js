import Vue from 'vue'
import VueRouter from 'vue-router'
import LoginView from "@/views/LoginView.vue";
import IndexView from "@/views/IndexView.vue";
import HomeView from "@/views/HomeView.vue";
import DelegateTracker from "@/views/DelegateTracker.vue";

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'login',
    component: LoginView
  },
  {
    path: '/index',
    name: 'index',
    component: IndexView,
    children : [{path:'',component: HomeView}]
  },
  {
    path: '/djjh5',
    name: 'djjh5',
    component: IndexView,
    children : [{path:'',component: DelegateTracker}]
  },
  {
    path: '/about',
    name: 'about',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/AboutView.vue')
  }
]

const router = new VueRouter({
  routes
})

export default router
